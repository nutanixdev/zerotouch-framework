from .main import AzureVmProvider


__all__ = ["AzureVmProvider"]
