from .main import init_decompile_context


__all__ = ["init_decompile_context"]
