from .descriptor import DescriptorType
from .object_type import ObjectDict

__all__ = ["ObjectDict", "DescriptorType"]
