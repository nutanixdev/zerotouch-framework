#!/bin/bash

set -ex

echo "Package uninstallation steps go here ..."
